

Al a�adir un nuevo proyecto recuerda a�adir la p�gina de propiedades ProyectosGLFG.props al nuevo proyecto:
Men� VER -> administrador de propiedades -> Agregar hoja de propiedades existente -> ProyectosGLFG.props -> Guardar

Para a�adir una nueva libreria, copia su directorio en la soluci�n y los bin de la libreria en el directorio bin de la soluci�n.
Y a�ade los nuevos elementos al archivo ProyectosGLFG.props en las lineas: IncludePath, LibraryPath y AdditionalDependencies.
Tambi�n puedes crear otras p�ginas de propiedades.